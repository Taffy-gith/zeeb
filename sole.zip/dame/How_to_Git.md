# GitHub-Issue-Branch in Eclipse bearbeiten

## 1. Branch für das Issue auf GitHub erstellen

1. Öffne auf GitHub das gewünschte Repository.
2. Gehe zu **Issues** und öffne das Issue.
3. Klicke rechts unter **Development** auf **Create a branch**.
4. Prüfe oder ändere den vorgeschlagenen Branch-Namen, zum Beispiel `42-login-fehler-beheben`.
5. Wähle unter **What's next** die lokale Bearbeitung aus und klicke auf **Create branch**.

Der Branch ist jetzt auf GitHub angelegt und mit dem Issue verknüpft.

## 2. Branch in Eclipse abrufen und auschecken

1. Klicke im **Project Explorer** mit der rechten Maustaste auf das Projekt.
2. Wähle **Team → Fetch from Origin**, damit Eclipse den neuen GitHub-Branch kennt.
3. Wähle danach **Team → Switch To → Other…**.
4. Suche unter den Remote-Branches nach `origin/42-login-fehler-beheben` und checke ihn aus.
5. Bestätige, dass ein lokaler Branch erstellt werden soll, der den Remote-Branch verfolgt.

Alternative über die Ansicht **Git Repositories**: Öffne **Branches → Remote Tracking**, klicke mit der rechten Maustaste auf `origin/<branch-name>` und wähle **Checkout**.

## 3. Aktuelle Änderungen pullen

Klicke erneut mit der rechten Maustaste auf das Projekt und wähle **Team → Pull**. Dadurch werden die neuesten Änderungen des verknüpften Remote-Branches geladen und integriert.

> Tipp: Führe den Pull vor Beginn deiner Arbeit und später erneut vor dem Push aus. Falls Konflikte auftreten, musst du diese zuerst auflösen und committen.

## 4. Änderungen committen

1. Bearbeite und teste den Code.
2. Klicke mit der rechten Maustaste auf das Projekt und wähle **Team → Commit…**.
3. Verschiebe die gewünschten Dateien in **Staged Changes**.
4. Schreibe eine aussagekräftige Commit-Nachricht, zum Beispiel `Fix login validation (#42)`.
5. Klicke auf **Commit**.

## 5. Änderungen zu GitHub pushen

1. Führe sicherheitshalber noch einmal **Team → Pull** aus.
2. Wähle anschließend **Team → Push to Upstream**.
3. Kontrolliere auf GitHub, ob der Commit im Issue-Branch angekommen ist.

Danach kannst du auf GitHub einen **Pull Request** vom Issue-Branch in den Ziel-Branch, meist `main`, erstellen. Mit `Closes #42` in der Pull-Request-Beschreibung wird das Issue beim Zusammenführen automatisch geschlossen.

## Kurzfassung

`GitHub: Branch erstellen` → `Eclipse: Fetch` → `Checkout/Switch` → `Pull` → `Ändern und testen` → `Commit` → `Pull` → `Push`

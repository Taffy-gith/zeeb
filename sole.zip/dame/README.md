# Dame

Ein Dame-Spiel in Java mit einer bedienbaren Swing-Oberfläche und getrennten
Paketen für Brett, Spieler, Regeln, Spielablauf und Darstellung.

## Modulstruktur

| Paket / Klasse | Aufgabe |
| --- | --- |
| `board` | Brettgröße, Felder und Figuren; führt die reine Verschiebung aus |
| `player` | Spieleridentität und Zugbeschreibung mit Start, Ziel und optionalem Schlagfeld |
| `ruleset.RuleSet` | Austauschbare Startaufstellung, legale Züge, Beförderung und Schlagfortsetzung |
| `game.Game` | Zugprüfung, Spielerwechsel, vorgemerkte Schläge, Neustart und Spielende |
| `game.Main` | Stellt Modell, Regeln, Controller und Fenster auf dem EDT zusammen |
| `gui.GameController` | Delegiert an `Game`, verwaltet Auswahl und benachrichtigt Ansichten |
| `gui.GameFrame` | Hauptfenster für einen übergebenen Controller |
| `gui.GamePanel` | Einbettbare Ansicht mit Brett, Status und Neustart |
| `gui.DebugPanel` | Auswahl für Figuren, Besitzer und Spieler am Zug sowie Stellungsaktionen |
| `gui.BoardPanel` | Stellt sämtliche Felder des übergebenen Bretts dar |
| `gui.SquareButton` / `PieceIcon` | Feldzustand, Markierungen und skalierbare Figurendarstellung |

```mermaid
classDiagram
    Main ..> Game : erstellt
    Main ..> Board : konfiguriert
    Main ..> Player : erstellt
    Main ..> StandardRules : wählt
    Main ..> GameController : erstellt
    Main ..> GameFrame : öffnet
    GameFrame *-- GamePanel
    GamePanel --> GameController : Aktionen und Änderungsbenachrichtigung
    GamePanel *-- BoardPanel
    GamePanel *-- DebugPanel
    DebugPanel --> GameController : bearbeitet Stellung
    BoardPanel --> Board : liest
    BoardPanel *-- SquareButton
    SquareButton --> PieceIcon
    GameController --> Game : delegiert
    GameController --> Square : Auswahl
    GameController --> Move : erlaubte Ziele
    Game --> Board
    Game --> Player
    Game --> RuleSet
    StandardRules ..|> RuleSet
    Board *-- Square
    Square --> Piece
    Piece --> Player
    Piece --> PieceType
    Move --> Square
```


package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import board.Piece;
import board.PieceType;
import board.Square;

public final class SquareButton extends JButton {
    private static final long serialVersionUID = 1L;
    private static final Color LIGHT = new Color(242, 210, 159);
    private static final Color DARK = new Color(138, 90, 50);
    private static final Color SELECTED = new Color(255, 200, 50);
    private static final Color TARGET = new Color(83, 178, 112);
    private final int row;
    private final int col;

    public SquareButton(int row, int col) {
        this.row = row;
        this.col = col;
        setContentAreaFilled(false);
        setOpaque(true);
        setMargin(new Insets(0, 0, 0, 0));
        setMinimumSize(new Dimension(0, 0));
        setPreferredSize(new Dimension(64, 64));
    }

    public void render(Square square, boolean selected, boolean target, boolean gameOver) {
        setBackground(target ? TARGET : square.isPlayable() ? DARK : LIGHT);
        setBorder(selected ? BorderFactory.createLineBorder(SELECTED, 4)
                : target ? BorderFactory.createLineBorder(TARGET.darker(), 4)
                : BorderFactory.createEmptyBorder(4, 4, 4, 4));
        setEnabled(square.isPlayable() && !gameOver);
        showPiece(square.getPiece());
        String description = "Zeile " + (row + 1) + ", Spalte " + (col + 1);
        if (!square.isEmpty()) {
            Piece piece = square.getPiece();
            description += ": Spieler " + piece.getOwner().getId()
                    + (piece.getType() == PieceType.QUEEN ? ", Dame" : ", Stein");
        } else {
            description += ": leer";
        }
        if (selected) description += ", ausgewählt";
        if (target) description += ", mögliches Ziel";
        setToolTipText(description);
        getAccessibleContext().setAccessibleName(description);
    }

    public void showPiece(Piece piece) {
        PieceIcon icon = piece == null ? null : new PieceIcon(piece.getOwner().getId(), piece.getType());
        setIcon(icon);
        setDisabledIcon(icon);
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return col;
    }
}

package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.Icon;

import board.PieceType;

public class PieceIcon implements Icon {

    private final Color pieceColor;
    private final PieceType pieceType;
    private final int size = 60;

    public PieceIcon(int playerId, PieceType pieceType) {
        if (playerId == 1) {
            this.pieceColor = Color.WHITE;
        } else if (playerId == 2) {
            this.pieceColor = Color.DARK_GRAY;
        } else {
            this.pieceColor = Color.getHSBColor(Math.floorMod(playerId * 137, 360) / 360f, 0.55f, 0.85f);
        }

        this.pieceType = pieceType;
    }
 
    @Override
    public int getIconWidth() {
        return size;
    }

    @Override
    public int getIconHeight() {
        return size;
    }

    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {

        Graphics2D g2 = (Graphics2D) g.create();

        // Keep pieces centered and visible even on a larger board or small cells.
        int available = c == null ? size : Math.max(1, Math.min(c.getWidth(), c.getHeight()) - 8);
        int renderedSize = Math.min(size, available);
        g2.translate(x + (size - renderedSize) / 2.0, y + (size - renderedSize) / 2.0);
        g2.scale(renderedSize / (double) size, renderedSize / (double) size);
        x = 0;
        y = 0;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        int margin = 6;
        int diameter = size - 2 * margin;

        int innerGap = 4;


        g2.setColor(pieceColor);
        g2.fillOval(
                x + margin,
                y + margin,
                diameter,
                diameter
        );

       
        if (pieceType == PieceType.QUEEN) {

            g2.setColor(Color.YELLOW);
            g2.fillOval(
                    x + margin + 1,
                    y + margin + 1,
                    diameter - 2,
                    diameter - 2
            );

            g2.setColor(pieceColor);
            g2.fillOval(
                    x + margin + innerGap,
                    y + margin + innerGap,
                    diameter - 2 * innerGap,
                    diameter - 2 * innerGap
            );
        }

        g2.setColor(Color.BLACK);
        g2.drawOval(
                x + margin,
                y + margin,
                diameter,
                diameter
        );

        if (pieceType == PieceType.QUEEN) {

            g2.drawOval(
                    x + margin + innerGap,
                    y + margin + innerGap,
                    diameter - 2 * innerGap,
                    diameter - 2 * innerGap
            );
        }

        g2.dispose();
    }
}

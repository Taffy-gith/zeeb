package gui;

import java.util.List;
import java.util.ArrayList;
import java.util.Objects;

import board.Board;
import board.PieceType;
import board.Square;
import game.Game;
import player.Move;
import player.Player;


public class GameController {

    private final Game game;
    private final List<Runnable> changeListeners = new ArrayList<>();
    private Square selectedSquare;
    private List<Move> selectedMoves = List.of();
    private boolean debugMode;

    public GameController(Game game) {
        this.game = Objects.requireNonNull(game);
        selectContinuation();
    }

    public List<Move> getAvailableMoves(Square square) {
        return game.getAvailableMoves(square);
    }

    public boolean playMove(Move move) {
        if (debugMode || !game.playMove(move)) {
            return false;
        }
        selectContinuation();
        fireChange();
        return true;
    }

    public void selectSquare(Square square) {
        if (debugMode || game.isGameOver() || !isOnBoard(square)) {
            return;
        }
        for (Move move : selectedMoves) {
            if (move.getTo() == square) {
                playMove(move);
                return;
            }
        }
        if (game.getRequiredContinuation() != null) {
            return;
        }
        if (square == selectedSquare) {
            selectedSquare = null;
            selectedMoves = List.of();
        } else {
            List<Move> moves = game.getAvailableMoves(square);
            if (moves.isEmpty()) {
                return;
            }
            selectedSquare = square;
            selectedMoves = List.copyOf(moves);
        }
        fireChange();
    }

    private boolean isOnBoard(Square square) {
        return square != null
                && square.getRow() >= 0 && square.getRow() < getBoard().getSize()
                && square.getCol() >= 0 && square.getCol() < getBoard().getSize()
                && getBoard().getSquare(square.getRow(), square.getCol()) == square;
    }

    private void selectContinuation() {
        selectedSquare = game.getRequiredContinuation();
        selectedMoves = selectedSquare == null ? List.of()
                : List.copyOf(game.getAvailableMoves(selectedSquare));
    }

    public Square getSelectedSquare() {
        return selectedSquare;
    }

    public List<Move> getSelectedMoves() {
        return selectedMoves;
    }

    public void addChangeListener(Runnable listener) {
        changeListeners.add(Objects.requireNonNull(listener));
    }

    public void removeChangeListener(Runnable listener) {
        changeListeners.remove(listener);
    }

    private void fireChange() {
        for (Runnable listener : List.copyOf(changeListeners)) {
            listener.run();
        }
    }

    public Board getBoard() {
        return game.getBoard();
    }

    public Player getCurrentPlayer() {
        return game.getCurrentPlayer();
    }

    public List<Player> getPlayers() {
        return game.getPlayers();
    }

    public boolean isDebugMode() {
        return debugMode;
    }

    public void setDebugMode(boolean enabled) {
        if (debugMode == enabled) return;
        if (enabled) game.resolveCurrentCaptures();
        debugMode = enabled;
        positionChanged();
    }

    public void placeDebugPiece(Square square, Player owner, PieceType type) {
        if (!debugMode) return;
        game.setPositionPiece(square, owner, type);
        positionChanged();
    }

    public void removeDebugPiece(Square square) {
        if (!debugMode) return;
        game.removePositionPiece(square);
        positionChanged();
    }

    public void clearDebugBoard() {
        if (!debugMode) return;
        game.clearPosition();
        positionChanged();
    }

    public void setDebugCurrentPlayer(Player player) {
        if (!debugMode) return;
        game.setPositionCurrentPlayer(player);
        positionChanged();
    }

    public void restoreDebugSetup() {
        if (debugMode) restart();
    }

    private void positionChanged() {
        selectContinuation();
        fireChange();
    }

    public boolean isGameOver() {
        return game.isGameOver();
    }

    public Square getRequiredContinuation() {
        return game.getRequiredContinuation();
    }

    public Player getWinner() {
        return game.getWinner();
    }

    public void restart() {
        game.reset();
        selectContinuation();
        fireChange();
    }
}

package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import player.Player;

public final class GamePanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private final GameController controller;
    private final BoardPanel boardPanel;
    private final DebugPanel debugPanel;
    private final JLabel statusLabel = new JLabel();
    private final Runnable changeListener = this::refresh;
    private boolean listening;

    public GamePanel(GameController controller) {
        super(new BorderLayout(0, 8));
        this.controller = controller;
        debugPanel = new DebugPanel(controller);
        boardPanel = new BoardPanel(controller.getBoard(), square -> {
            if (controller.isDebugMode()) debugPanel.editSquare(square);
            else controller.selectSquare(square);
        });
        JButton restartButton = new JButton("Neustart");
        restartButton.addActionListener(event -> controller.restart());
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEADING));
        controls.add(statusLabel);
        controls.add(restartButton);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        add(boardPanel, BorderLayout.CENTER);
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(controls, BorderLayout.NORTH);
        bottom.add(debugPanel, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        listen();
        refresh();
    }

    @Override
    public void addNotify() {
        super.addNotify();
        listen();
        refresh();
    }

    @Override
    public void removeNotify() {
        controller.removeChangeListener(changeListener);
        listening = false;
        super.removeNotify();
    }

    private void listen() {
        if (!listening) {
            controller.addChangeListener(changeListener);
            listening = true;
        }
    }

    private void refresh() {
        debugPanel.refresh();
        boolean gameOver = !controller.isDebugMode() && controller.isGameOver();
        boardPanel.render(controller.getSelectedSquare(), controller.getSelectedMoves(), gameOver);
        if (controller.isDebugMode()) {
            statusLabel.setText("Debug: Felder anklicken zum Bearbeiten. Spieler "
                    + controller.getCurrentPlayer().getId() + " am Zug.");
        } else if (gameOver) {
            Player winner = controller.getWinner();
            statusLabel.setText(winner == null ? "Spiel beendet."
                    : "Spieler " + winner.getId() + " gewinnt!");
        } else {
            String hint = controller.getRequiredContinuation() != null ? "Weiter schlagen."
                    : controller.getSelectedSquare() == null ? "Stein auswählen."
                    : controller.getSelectedMoves().stream().anyMatch(move -> move.getCaptured() != null)
                            ? "Schlagziel auswählen." : "Ziel auswählen.";
            statusLabel.setText("Spieler " + controller.getCurrentPlayer().getId() + " am Zug. " + hint);
        }
    }
}

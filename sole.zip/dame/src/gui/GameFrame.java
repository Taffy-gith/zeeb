package gui;

import java.awt.Dimension;
import javax.swing.JFrame;

public final class GameFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    public GameFrame(GameController controller) {
        super("Dame");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(new GamePanel(controller));
        setMinimumSize(new Dimension(700, 700));
        pack();
        setLocationRelativeTo(null);
    }
}

package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import board.PieceType;
import board.Square;
import player.Player;

/** Position-editor controls. Written by ChatGPT */
public final class DebugPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private final GameController controller;
    private final JCheckBox enabled = new JCheckBox("Debug-Modus");
    private final JComboBox<PieceType> pieceType = new JComboBox<>(PieceType.values());
    private final JComboBox<Player> owner;
    private final JComboBox<Player> currentPlayer;
    private final JCheckBox remove = new JCheckBox("Entfernen");
    private final JPanel editor = new JPanel(new GridLayout(2, 1));
    private boolean refreshing;

    public DebugPanel(GameController controller) {
        super(new BorderLayout());
        this.controller = controller;
        Player[] players = controller.getPlayers().toArray(new Player[0]);
        owner = new JComboBox<>(players);
        currentPlayer = new JComboBox<>(players);
        owner.setSelectedItem(controller.getCurrentPlayer());
        setBorder(BorderFactory.createTitledBorder("Stellung bearbeiten"));

        JPanel pieceControls = new JPanel(new FlowLayout(FlowLayout.LEADING));
        addLabeled(pieceControls, "Figurentyp", pieceType);
        addLabeled(pieceControls, "Besitzer", owner);
        pieceControls.add(remove);
        remove.addActionListener(event -> {
            pieceType.setEnabled(!remove.isSelected());
            owner.setEnabled(!remove.isSelected());
        });

        JPanel boardControls = new JPanel(new FlowLayout(FlowLayout.LEADING));
        addLabeled(boardControls, "Am Zug", currentPlayer);
        JButton clear = new JButton("Brett leeren");
        clear.addActionListener(event -> controller.clearDebugBoard());
        JButton setup = new JButton("Standardaufstellung");
        setup.addActionListener(event -> controller.restoreDebugSetup());
        boardControls.add(clear);
        boardControls.add(setup);
        editor.add(pieceControls);
        editor.add(boardControls);
        add(enabled, BorderLayout.NORTH);
        add(editor, BorderLayout.CENTER);
        enabled.addActionListener(event -> controller.setDebugMode(enabled.isSelected()));
        currentPlayer.addActionListener(event -> {
            if (!refreshing) controller.setDebugCurrentPlayer((Player) currentPlayer.getSelectedItem());
        });
        refresh();
    }

    private static void addLabeled(JPanel panel, String text, JComboBox<?> input) {
        JLabel label = new JLabel(text + ":");
        label.setLabelFor(input);
        input.getAccessibleContext().setAccessibleName(text);
        panel.add(label);
        panel.add(input);
    }

    public void editSquare(Square square) {
        if (remove.isSelected()) {
            controller.removeDebugPiece(square);
        } else {
            controller.placeDebugPiece(square, (Player) owner.getSelectedItem(),
                    (PieceType) pieceType.getSelectedItem());
        }
    }

    public void refresh() {
        refreshing = true;
        try {
            enabled.setSelected(controller.isDebugMode());
            editor.setVisible(controller.isDebugMode());
            currentPlayer.setSelectedItem(controller.getCurrentPlayer());
        } finally {
            refreshing = false;
        }
        revalidate();
        repaint();
    }
}

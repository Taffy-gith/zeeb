package gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.JPanel;
import board.Board;
import board.Square;
import player.Move;

/** Renders the supplied board */
public final class BoardPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private final Board board;
    private final SquareButton[][] squareButtons;

    public BoardPanel(Board board, Consumer<Square> onSquareSelected) {
        this.board = board;
        int size = board.getSize();
        squareButtons = new SquareButton[size][size];
        setLayout(new GridLayout(size, size));
        setPreferredSize(new Dimension(600, 600));
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                Square square = board.getSquare(row, col);
                SquareButton button = new SquareButton(row, col);
                button.addActionListener(event -> onSquareSelected.accept(square));
                squareButtons[row][col] = button;
                add(button);
            }
        }
        render(null, List.of(), false);
    }

    public void render(Square selected, List<Move> moves, boolean gameOver) {
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                Square square = board.getSquare(row, col);
                boolean target = moves.stream().anyMatch(move -> move.getTo() == square);
                squareButtons[row][col].render(square, square == selected, target, gameOver);
            }
        }
    }

    public void updateIcon(Square square) {
        squareButtons[square.getRow()][square.getCol()].showPiece(square.getPiece());
    }
}

package player;

import java.util.Objects;
import board.Square;


public class Move {
    private final Square from;
    private final Square to;
    private final Square captured;
 
    public Move(Square from, Square to, Square captured) {
        this.from = from;
        this.to = to;
        this.captured = captured;
    }
    
    public Move(Square from, Square to) {
        this.from = from;
        this.to = to;
        this.captured = null;
    }
    
    @Override 
    public String toString() {
    	if (captured!=null) {
    		return "Spieler zieht von " + from + " zu " + to + " und schlägt " + captured;
    	}
    	else {
    		return "Spieler zieht von " + from + " zu " + to;
    	}
    }
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Move)) {
            return false;
        }

        Move other = (Move) obj;

        return from.equals(other.from) && to.equals(other.to) && Objects.equals(captured, other.captured);
    }

    public Square getFrom() {
        return from;
    }

    public Square getTo() {
        return to;
    }

    public Square getCaptured() {
        return captured;
    }
    
}

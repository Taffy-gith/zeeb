package board;

public enum PieceType {
	PAWN,
	QUEEN
}

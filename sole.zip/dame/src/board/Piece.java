package board;

import player.Player;

public class Piece {
	private final Player owner;
	private PieceType type;
	
	public Piece(Player owner, PieceType type) {
        this.owner = owner;
        this.type = type;
    }
    public Player getOwner() {
        return owner;
    }

    public PieceType getType() {
        return type;
    }

    public void promote() {
        type = PieceType.QUEEN;
    }
}

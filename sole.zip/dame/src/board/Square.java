package board;

public class Square {
	private final int row;
	private final int col;
	private final boolean playable;
	private Piece piece;

	
	Square(int row, int col, boolean playable){
        this.row = row;
        this.col = col;
		this.playable = playable;
		this.piece = null;
	}

    public int getRow() { 
    	return row; 
    }
    
    public int getCol() { 
    	return col; 
    }
    
    public Piece getPiece() {
    	return piece; 
    }

    public boolean isPlayable() {
        return playable;
    }
    
    public boolean isEmpty() {
        return piece == null;
    }


	protected void setPiece(Piece piece) {
		this.piece = piece;
	}
}

package board;

import player.Move;

public class Board {
    private final int size;
    private final int initialPieceRows;
    
	private final Square[][] squares;
	
	public Board(int size, int initialPieceRows) {
		this.size = size;
		this.initialPieceRows = initialPieceRows;

		squares = new Square[size][size];
		for (int row = 0; row < size; row++) {
			for (int column = 0; column < size; column++) {
				squares[row][column] = new Square(row, column, isPlayableSquare(row, column));
			}
		}
	}


	public void placePiece(Square square, Piece piece) {
		square.setPiece(piece);
	}

	public void makeMove(Move move){ 
		Square from = move.getFrom();
		Square to = move.getTo();

		Piece piece = from.getPiece();
		from.setPiece(null);
		to.setPiece(piece);
	}

	public Square getSquare(int row, int column) {
		return squares[row][column];
	}

	public int getSize() {
		return size;
	}

	public int getInitialPieceRows() {
		return initialPieceRows;
	}


	private boolean isPlayableSquare(int row, int column) {
		return (row + column) % 2 == 0;
	}
	
	public void removePiece(Square square) {
		square.setPiece(null);
	}
}

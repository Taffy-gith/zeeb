package game;

import java.util.ArrayList;
import java.util.List;

import board.Board;
import board.Piece;
import board.PieceType;
import board.Square;
import player.Move;
import player.Player;
import ruleset.RuleSet;

public class Game {
    private final Board board;
    private final List<Player> players;
    private final RuleSet rules;
    private final List<Square> capturedSquares = new ArrayList<>();
    private Square requiredContinuation;
    private int currentPlayerIndex;

    public Game(Board board, List<Player> players, RuleSet rules) {
        this.board = board;
        this.rules = rules;
        this.players = new ArrayList<>(players);
        this.currentPlayerIndex = 0;
        this.requiredContinuation = null;
        this.rules.setup(this.board, this.players);
    }

    /** Plays one step or jump, keeping the turn if another capture is required. */
    public boolean playMove(Move move) {
        if (isGameOver() || move == null) {
            return false;
        }

        boolean moved = movePiece(move);
        if (!moved) return false;

        Piece movedPiece = move.getTo().getPiece();
        boolean promoted = rules.shouldPromote(board, movedPiece, move.getTo());
        if (promoted) {
            movedPiece.promote();
        }

        rememberCapture(move);
        if (move.getCaptured() != null
                && rules.mustContinue(board, getCurrentPlayer(), move.getTo(), capturedSquares, promoted)) {
            requiredContinuation = move.getTo();
            return true;
        }

        finishTurn();
        return true;
    }

    public List<Move> getAvailableMoves(Square square) {
        if (isGameOver()) {
            return new ArrayList<>();
        }
        return getLegalMoves(square);
    }

    /** Returns true when the current player has no legal moves and has therefore lost. */
    public boolean checkWin() {
        Player currentPlayer = getCurrentPlayer();
        for (int row = 0; row < board.getSize(); row++) {
            if (rowHasLegalMove(row, currentPlayer)) {
                return false;
            }
        }
        return true;
    }

    public Player getWinner() {
        if (!isGameOver()) {
            return null;
        }

        int previousPlayer = Math.floorMod(
                currentPlayerIndex - 1,
                players.size()
        );
        return players.get(previousPlayer);
    }

    public void reset() {
        rules.setup(board, players);
        capturedSquares.clear();
        currentPlayerIndex = 0;
        requiredContinuation = null;
    }
    
    public boolean isGameOver() {
        return checkWin();
    }

    public Player getCurrentPlayer() {
        return players.get(currentPlayerIndex);
    }

    public Square getRequiredContinuation() {
        return requiredContinuation;
    }

    public Board getBoard() {
        return board;
    }

    public List<Player> getPlayers() {
        return List.copyOf(players);
    }

    public void setPositionPiece(Square square, Player owner, PieceType type) {
        resolveCurrentCaptures();
        board.placePiece(square, new Piece(owner, type));
    }

    public void removePositionPiece(Square square) {
        resolveCurrentCaptures();
        board.removePiece(square);
    }

    public void clearPosition() {
        resolveCurrentCaptures();
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                board.removePiece(board.getSquare(row, col));
            }
        }
    }

    public void setPositionCurrentPlayer(Player player) {
        int index = players.indexOf(player);
        resolveCurrentCaptures();
        currentPlayerIndex = index;
    }

    /** Removes pending captures and clears the capture chain without switching players. */
    public void resolveCurrentCaptures() {
        for (Square captured : capturedSquares) {
            board.removePiece(captured);
        }
        capturedSquares.clear();
        requiredContinuation = null;
    }

    private boolean movePiece(Move move) {
        if (move.getFrom() == null || move.getTo() == null) {
            return false;
        }

        List<Move> legalMoves = getLegalMoves(move.getFrom());
        if (!legalMoves.contains(move)) {
            return false;
        }

        board.makeMove(move);
        return true;
    }

    private List<Move> getLegalMoves(Square square) {
        return rules.getLegalMoves(board, getCurrentPlayer(), square, requiredContinuation, capturedSquares);
    }

    /** Saves the move until the turn ends so captured pieces still block movement. */
    private void rememberCapture(Move move) {
        if (move.getCaptured() != null) {
            capturedSquares.add(move.getCaptured());
        }
    }

    private void finishTurn() {
        for (Square capturedSquare : capturedSquares) {
            board.removePiece(capturedSquare);
        }
        capturedSquares.clear();
        requiredContinuation = null;
        switchTurn();
    }

    private void switchTurn() {
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
    }

    private boolean rowHasLegalMove(int row, Player player) {
        for (int column = 0; column < board.getSize(); column++) {
            if (pieceHasLegalMove(board.getSquare(row, column), player)) {
                return true;
            }
        }
        return false;
    }

    private boolean pieceHasLegalMove(Square square, Player player) {
        if (square.isEmpty() || square.getPiece().getOwner() != player) {
            return false;
        }
        return !getLegalMoves(square).isEmpty();
    }
}

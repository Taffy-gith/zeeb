package game;

import java.util.List;

import board.Board;
import gui.GameController;
import gui.GameFrame;
import player.Player;
import ruleset.StandardRules;

public class Main {
    public static void main(String[] args) {
    	
            Game game = new Game(new Board(8, 3), List.of(new Player(1), new Player(2)), new StandardRules());
            
            GameFrame frame = new GameFrame(new GameController(game));
            
            frame.setVisible(true);
    }
}

package ruleset;


import java.util.List;

import board.Board;
import board.Piece;
import board.Square;
import player.Move;
import player.Player;

public interface RuleSet {
	
    /** Sets up a new game on an empty board. */
    void setup(Board board, List<Player> players);

    /** Returns the legal moves for the selected square. */
    List<Move> getLegalMoves(
            Board board,
            Player player,
            Square selected,
            Square requiredContinuation,
            List<Square> capturedSquares
    );

    /** Returns whether the moved piece should be promoted at its destination. */
    boolean shouldPromote(
            Board board,
            Piece piece,
            Square destination
    );

    /** Decides whether the capturing piece must continue, after movement and promotion. */
    boolean mustContinue(
            Board board,
            Player player,
            Square destination,
            List<Square> capturedSquares,
            boolean promoted
    );

}

package ruleset;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import board.Board;
import board.Piece;
import board.PieceType;
import board.Square;
import player.Move;
import player.Player;

public class StandardRules implements RuleSet {

    private static final int[][] DIAGONALS = {
        {-1, -1},
        {-1, 1},
        {1, -1},
        {1, 1}
    };

    private final Map<Player, Integer> forwardDirections = new IdentityHashMap<>();

	@Override
	public void setup(Board board, List<Player> players) {
		Player player1 = players.get(0);
		Player player2 = players.get(1);
		forwardDirections.clear();
		forwardDirections.put(player1, -1);
		forwardDirections.put(player2, 1);

		clear(board);
		for (int row = 0; row < board.getInitialPieceRows(); row++) {
			setupRow(board, row, player2);
		}
		for (int row = board.getSize() - board.getInitialPieceRows(); row < board.getSize(); row++) {
			setupRow(board, row, player1);
		}

	}

	@Override
	public List<Move> getLegalMoves(
			Board board, Player player, Square selected,
			Square requiredContinuation, List<Square> capturedSquares) {
		if (!isOwnedPieceOnBoard(board, selected, player) || (requiredContinuation != null && selected != requiredContinuation)) {
			return new ArrayList<>();
		}

		List<Move> moves = getMovesForPiece(board, player, selected, capturedSquares);
		
		if (requiredContinuation != null || hasCapture(board, player, capturedSquares)) {
			return getCaptureMoves(moves);
		}
		return moves;
	}

	@Override
	public boolean shouldPromote(Board board, Piece piece, Square destination) {
		if (board == null || piece == null || destination == null || piece.getType() != PieceType.PAWN) {
			return false;
		}

		Integer forward = forwardDirections.get(piece.getOwner());
		return forward != null && ((forward < 0 && destination.getRow() == 0) || (forward > 0 && destination.getRow() == board.getSize() - 1));
	}

	@Override
	public boolean mustContinue(Board board, Player player, Square destination, List<Square> capturedSquares, boolean promoted) {
		if (promoted) {
			return false;
		}
		List<Move> continuationMoves = getLegalMoves(board, player, destination, destination, capturedSquares);
		return !continuationMoves.isEmpty();
	}

	private List<Move> getPawnMoves(Board board, Player player, Square square) {
		List<Move> moves = new ArrayList<>();
		for (int columnDirection : new int[] {-1, 1}) {
			addPawnMovesInDirection(board, player, square, columnDirection, moves);
		}
		return moves;
	}

	private void addPawnMovesInDirection(Board board, Player player, Square square, int columnDirection, List<Move> moves) {
		int forwardDirection = forwardDirections.get(player);
		Square adjacentSquare = getSquareOrNull(board, square.getRow() + forwardDirection, square.getCol() + columnDirection);
		
		if (isEmpty(adjacentSquare)) {
			moves.add(new Move(square, adjacentSquare));
		}
		
		Square captureDestination = getSquareOrNull(board, square.getRow() + 2 * forwardDirection, square.getCol() + 2 * columnDirection);
		
		if (isOpponent(adjacentSquare, player) && isEmpty(captureDestination)) {
			moves.add(new Move(square, captureDestination, adjacentSquare));
		}
	}

	private List<Move> getQueenMoves(Board board, Player player, Square square) {
		List<Move> moves = new ArrayList<>();

		for (int[] direction : DIAGONALS) {
			addQueenMovesInDirection(board, player, square, direction, moves);
		}

		return moves;
	}

	private void addQueenMovesInDirection(
			Board board, Player player, Square square, int[] direction, List<Move> moves) {
		int row = square.getRow() + direction[0];
		int column = square.getCol() + direction[1];
		Square nextSquare = getSquareOrNull(board, row, column);
		while (isEmpty(nextSquare)) {
			moves.add(new Move(square, nextSquare));
			row += direction[0];
			column += direction[1];
			nextSquare = getSquareOrNull(board, row, column);
		}
		if (!isOpponent(nextSquare, player)) {
			return;
		}
		Square destination = getSquareOrNull(board, row + direction[0], column + direction[1]);
		if (isEmpty(destination)) {
			moves.add(new Move(square, destination, nextSquare));
		}
	}

	private List<Move> getCaptureMoves(List<Move> moves) {
		List<Move> captures = new ArrayList<>();
		for (Move move : moves) {
			if (move.getCaptured() != null) {
				captures.add(move);
			}
		}
		return captures;
	}

	private List<Move> getMovesForPiece(
			Board board, Player player, Square square, List<Square> capturedSquares) {
		List<Move> moves = getMovesForPieceType(board, player, square);
		
		Iterator<Move> iterator = moves.iterator();
		
		while (iterator.hasNext()) {
			Move move = iterator.next();
			if (move.getCaptured() != null && capturedSquares.contains(move.getCaptured())) {
				iterator.remove();
			}
		}
		
		return moves;
	}

	private List<Move> getMovesForPieceType(Board board, Player player, Square square) {
		if (square.getPiece().getType() == PieceType.PAWN) {
			return getPawnMoves(board, player, square);
		}
		if (square.getPiece().getType() == PieceType.QUEEN) {
			return getQueenMoves(board, player, square);
		}
		return new ArrayList<>();
	}

	private boolean hasCapture(Board board, Player player, List<Square> capturedSquares) {
		for (int row = 0; row < board.getSize(); row++) {
			if (rowHasCapture(board, row, player, capturedSquares)) {
				return true;
			}
		}
		return false;
	}

	private boolean pieceCanCapture(Board board, Square square, Player player, List<Square> capturedSquares) {
		return isOwnedPieceOnBoard(board, square, player) && !getCaptureMoves(getMovesForPiece(board, player, square, capturedSquares)).isEmpty();
	}

	private boolean rowHasCapture(Board board, int row, Player player, List<Square> capturedSquares) {
		for (int column = 0; column < board.getSize(); column++) {
			Square square = board.getSquare(row, column);
			
			if (pieceCanCapture(board, square, player, capturedSquares)) {
				return true;
			}
		}
		return false;
	}

	private boolean isOwnedPieceOnBoard(Board board, Square square, Player player) {
		return board != null
        		&& square != null
        		&& !square.isEmpty()
        		&& square.getPiece().getOwner() == player
        		&& board.getSquare(square.getRow(), square.getCol()) == square;
	}

	
	private boolean isEmpty(Square square) {
		 return square != null && square.isEmpty();
	}

	private boolean isOpponent(Square square, Player player) {
		return square != null
				&& !square.isEmpty()
				&& square.getPiece().getOwner() != player;
	}

	private Square getSquareOrNull(Board board, int row, int column) {
		if (row < 0 || row >= board.getSize() || column < 0 || column >= board.getSize()) {
			return null;
		}
		return board.getSquare(row, column);
	}

	private void clear(Board board) {
		for (int row = 0; row < board.getSize(); row++) {
			for (int column = 0; column < board.getSize(); column++) {
				board.placePiece(board.getSquare(row, column), null);
			}
		}
	}

	private void setupRow(Board board, int row, Player player) {
		for (int column = 0; column < board.getSize(); column++) {
			Square square = board.getSquare(row, column);
			if (square.isPlayable()) {
				board.placePiece(square, new Piece(player, PieceType.PAWN));
			}
		}
	}

}
